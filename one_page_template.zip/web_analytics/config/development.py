

import os


DEBUG = True
SECRET_KEY = os.urandom(36)
SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(os.path.dirname(__file__), '../data-dev.sqlite3')
SQLALCHEMY_MIGRATE_REPO = os.path.join(os.path.dirname(__file__), 'db_repository')


OAUTH_CREDENTIALS = {
    'facebook': {
        'id': '1411393735770403',
        'secret': '3605325e32242503ff7888b6e3b3ba13'
    },
    'twitter': {
        'id': '3RzWQclolxWZIMq5LJqzRZPTl',
        'secret': 'm9TEd58DSEtRrZHpz2EjrV9AhsBRxKMo8m3kuIZj3zLwzwIimt'
    }
}